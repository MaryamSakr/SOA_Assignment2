package com.universityServices.universityServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniversityServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniversityServicesApplication.class, args);
	}

}
